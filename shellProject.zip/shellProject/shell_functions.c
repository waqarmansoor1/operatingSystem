#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "shell_functions.h"

// -------- CHECKS --------
int hasPipe(char *input) {
    return strchr(input, '|') != NULL;
}

int hasInput(char *input) {
    return strchr(input, '<') != NULL;
}

int hasOutput(char *input) {
    return strchr(input, '>') != NULL;
}

// -------- TOKENIZE --------
void tokenize(char *cmd, char **args) {
    int i = 0;
    char *tok = strtok(cmd, " ");
    while (tok != NULL) {
        args[i++] = tok;
        tok = strtok(NULL, " ");
    }
    args[i] = NULL;
}

// -------- EXECUTE NORMAL --------
void executeSingle(char *cmd) {
    char *args[100];
    tokenize(cmd, args);

    execvp(args[0], args);
    printf("Command not found\n");
    _exit(1);
}

// -------- INPUT REDIRECTION --------
void executeWithInput(char *cmd) {
    char *command = strtok(cmd, "<");
    char *file = strtok(NULL, " ");

    int fd = open(file, O_RDONLY);
    if (fd < 0) {
        printf("File not found\n");
        _exit(1);
    }

    dup2(fd, 0);
    close(fd);

    executeSingle(command);
}

// -------- OUTPUT REDIRECTION ( > and >> ) --------
void executeWithOutput(char *cmd) {

    int append = 0;
    char *pos;

    // detect >>
    if ((pos = strstr(cmd, ">>")) != NULL) {
        append = 1;
    }

    char *command;
    char *file;

    if (append) {
        *pos = '\0';           // split command
        command = cmd;
        file = pos + 2;        // skip >>
    }
    else {
        pos = strchr(cmd, '>');
        if (pos == NULL) {
            printf("Syntax error\n");
            _exit(1);
        }

        *pos = '\0';
        command = cmd;
        file = pos + 1;        // skip >
    }

    // remove leading spaces from filename
    while (*file == ' ') file++;

    if (*file == '\0') {
        printf("No file specified\n");
        _exit(1);
    }

    int fd;

    if (append) {
        fd = open(file, O_CREAT | O_WRONLY | O_APPEND, 0666);
    } else {
        fd = open(file, O_CREAT | O_WRONLY | O_TRUNC, 0666);
    }

    if (fd < 0) {
        perror("File error");
        _exit(1);
    }

    dup2(fd, 1);
    close(fd);

    executeSingle(command);
}

// -------- PIPE PARSING --------
void parseInput(char *input, char **commands, int *count) {
    int i = 0;
    char *tok = strtok(input, "|");
    while (tok != NULL) {
        commands[i++] = tok;
        tok = strtok(NULL, "|");
    }
    *count = i;
}

// -------- PIPE EXECUTION --------
void executePipes(char *input) {

    char *commands[50];
    int n = 0;

    parseInput(input, commands, &n);

    int pipes[n-1][2];

    for (int i = 0; i < n-1; i++) {
        pipe(pipes[i]);
    }

    for (int i = 0; i < n; i++) {

        if (fork() == 0) {

            if (i > 0) {
                dup2(pipes[i-1][0], 0);
            }

            if (i < n-1) {
                dup2(pipes[i][1], 1);
            }

            for (int j = 0; j < n-1; j++) {
                close(pipes[j][0]);
                close(pipes[j][1]);
            }

            if (hasInput(commands[i])) {
                executeWithInput(commands[i]);
            }
            else if (hasOutput(commands[i])) {
                executeWithOutput(commands[i]);
            }
            else {
                executeSingle(commands[i]);
            }
        }
    }

    for (int i = 0; i < n-1; i++) {
        close(pipes[i][0]);
        close(pipes[i][1]);
    }

    for (int i = 0; i < n; i++) {
        wait(NULL);
    }
}
