#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include "shell_functions.h"

int main() {

printf("\n");
printf("########################################\n");
printf("#                                      #\n");
printf("#        W E L C O M E   T O           #\n");
printf("#        CUSTOM FAST UNIX SHELL        #\n");
printf("#                                      #\n");
printf("########################################\n");
printf("#  Type 'exit' to quit                 #\n");
printf("########################################\n\n");

    char input[256];

    while (1) {

        printf("myshell> ");
        fgets(input, sizeof(input), stdin);

        input[strcspn(input, "\n")] = 0;

        if (strcmp(input, "exit") == 0) {
            break;
        }

        // built-in cd
        if (strncmp(input, "cd ", 3) == 0) {
            char *path = input + 3;
            if (chdir(path) != 0) {
                printf("Failed to change directory\n");
            }
            continue;
        }

        int pid = fork();

        if (pid == 0) {

            if (hasPipe(input)) {
                executePipes(input);
            }
            else if (hasInput(input)) {
                executeWithInput(input);
            }
            else if (hasOutput(input)) {
                executeWithOutput(input);
            }
            else {
                executeSingle(input);
            }

            _exit(0);
        }
        else {
            wait(NULL);
        }
    }

    return 0;
}
