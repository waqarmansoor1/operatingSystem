#ifndef SHELL_FUNCTIONS_H
#define SHELL_FUNCTIONS_H

void parseInput(char *input, char **commands, int *count);
void tokenize(char *cmd, char **args);

void executeSingle(char *cmd);
void executeWithInput(char *cmd);
void executeWithOutput(char *cmd);
void executePipes(char *input);

int hasPipe(char *input);
int hasInput(char *input);
int hasOutput(char *input);

#endif
